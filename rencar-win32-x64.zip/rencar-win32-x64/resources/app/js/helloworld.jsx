var React = require('react');
var ReactDOM = require('react-dom');

ReactDOM.render(
  <h1>렌카 메신저</h1>,
  document.getElementById('app')
);
